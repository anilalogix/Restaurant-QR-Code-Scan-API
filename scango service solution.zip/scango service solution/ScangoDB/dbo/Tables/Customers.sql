﻿CREATE TABLE [dbo].[Customers]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [FullName] NVARCHAR(50) NULL, 
    [PhoneNumber] NUMERIC NOT NULL, 
    [CarNumber] NUMERIC(4) NULL, 
    [MailID] NVARCHAR(50) NULL
)
