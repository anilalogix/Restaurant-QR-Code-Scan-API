﻿CREATE TABLE [dbo].[MenuTypes]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [MenuName] NVARCHAR(50) NOT NULL, 
    [ImagePath] NVARCHAR(300) NULL
)
