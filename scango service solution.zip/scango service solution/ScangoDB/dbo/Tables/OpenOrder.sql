﻿CREATE TABLE [dbo].[OpenOrder]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [OrderID] NCHAR(10) NOT NULL, 
    [ServiceType] NCHAR(10) NOT NULL, 
    [CustomerID] NCHAR(10) NOT NULL, 
    [RestaurantID] NVARCHAR(50) NOT NULL, 
    [OrderAmount] NUMERIC(18, 2) NOT NULL, 
    [Status] NVARCHAR(50) NOT NULL, 
    [StatusDatetime] DATETIME NOT NULL, 
    [Items] BIGINT NULL
)
