﻿CREATE TABLE [dbo].[PaymentTypes]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [ Name] NVARCHAR(50) NOT NULL
)
