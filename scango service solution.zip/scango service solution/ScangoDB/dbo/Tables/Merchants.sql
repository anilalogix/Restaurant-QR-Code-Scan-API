﻿CREATE TABLE [dbo].[Merchants]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [MerchantName] NVARCHAR(100) NOT NULL, 
    [Address] NVARCHAR(300) NOT NULL, 
    [MerchantPhNo] NUMERIC(10) NOT NULL, 
    [MerchantMailId] NCHAR(10) NOT NULL, 
    [GSTNumber] NVARCHAR(50) NULL, 
    [FSSAI] NVARCHAR(50) NULL, 
    [MerchantIdentification] NVARCHAR(10) NOT NULL UNIQUE
)
