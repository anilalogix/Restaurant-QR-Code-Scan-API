﻿CREATE TABLE [dbo].[Menu]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [MenuType] NCHAR(10) NOT NULL, 
    [Category] NCHAR(10) NOT NULL, 
    [NameOfTheDish] NCHAR(10) NOT NULL, 
    [ ActualPrice] NUMERIC NOT NULL, 
    [DiscountedPrice] NUMERIC NOT NULL, 
    [QuantityVariant] NVARCHAR(50) NULL, 
    [Description] NVARCHAR(300) NULL, 
    [ImagePath] NVARCHAR(300) NULL, 
    [FoodType] NCHAR(10) NOT NULL, 
    [Available] NCHAR(10) NOT NULL
)
