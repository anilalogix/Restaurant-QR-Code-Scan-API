﻿CREATE TABLE [dbo].[OrderStatusTypes]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NVARCHAR(50) NOT NULL
)
