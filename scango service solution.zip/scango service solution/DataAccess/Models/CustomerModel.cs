﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models;

public class CustomerModel
{
    public int customerId { get; set; }
    public String? fullName { get; set; }
    public int phoneNumber { get; set; }
    public int carNumber { get; set; }
    public String? mailId { get; set; }

}
