﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models;

public class MerchantModel
{
    public int MerchantId { get; set; }
    public string? MerchantName { get; set; }
    public string? MerchantAddress { get; set; }
    public int MerchantPhNo { get; set; }
    public string? MerchantMailId { get; set; }
    public string? GSTNumber { get; set; }
    public string? FSSAINumber { get; set; }
    public string? MerchantLogoPath { get; set; }

}
