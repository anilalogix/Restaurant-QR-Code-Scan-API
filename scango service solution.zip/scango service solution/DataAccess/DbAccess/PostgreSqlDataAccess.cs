﻿using Microsoft.Extensions.Configuration;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using Npgsql;
using DapperExtensions.Sql;
using DapperExtensions;

namespace DataAccess.DbAccess;
public class PostgreSqlDataAccess : IPostgreSqlDataAccess
{
    private readonly IConfiguration _config;

    public PostgreSqlDataAccess(IConfiguration config)
    {
        _config = config;
    }

    public async Task<IEnumerable<T>> LoadData<T, U>(string storedProcedure, U parameters, string connectionId = "Default")
    {
        DapperExtensions.DapperExtensions.SqlDialect = new PostgreSqlDialect();
        DapperAsyncExtensions.SqlDialect = new PostgreSqlDialect();

        using IDbConnection connection = new NpgsqlConnection(_config.GetConnectionString(connectionId));
        return await connection.QueryAsync<T>(storedProcedure, parameters);
    }

    public async Task SaveData<T>(string storedProcedure, T parameters, string connectionId = "Default")
    {
        DapperExtensions.DapperExtensions.SqlDialect = new PostgreSqlDialect();
        DapperAsyncExtensions.SqlDialect = new PostgreSqlDialect();

        using IDbConnection connection = new NpgsqlConnection(_config.GetConnectionString(connectionId));

        await connection.ExecuteAsync(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
    }
}
