﻿using DataAccess.DbAccess;
using DataAccess.Models;
using Npgsql;
using NpgsqlTypes;

namespace DataAccess.Data;
public class CustomerData : ICustomerData
{
    private readonly IPostgreSqlDataAccess _database;

    public CustomerData(IPostgreSqlDataAccess database)
    {
        _database = database;
    }

    public async Task<CustomerModel?> GetCustomer(int p_customerid)
    {
        var results = await _database.LoadData<CustomerModel, dynamic>("spcustomer_getcustomer", new { CustomerId = p_customerid });
        return results.FirstOrDefault();
    }

    public async Task<CustomerModel?> GetCustomers()
    {
        string s = string.Empty;
        string sqlCmd = @"SELECT public.fncustomer_getcustomers()";
        NpgsqlCommand cmd = new NpgsqlCommand(sqlCmd);
        cmd.CommandType = System.Data.CommandType.Text;
        var results = await _database.LoadData<CustomerModel, dynamic>(cmd.CommandText, new { });
        return results.FirstOrDefault();
    }

    public Task InsertCustomer(CustomerModel customer) => _database.SaveData(@"SELECT public.fncustomer_addcusto()", new
    {
        customer.fullName,
        customer.phoneNumber,
        customer.carNumber,
        customer.mailId
    });

}
