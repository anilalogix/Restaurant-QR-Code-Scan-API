﻿using DataAccess.Models;

namespace DataAccess.Data;
public interface IMerchantData
{
    Task<MerchantModel?> GestMerchant(int merchantId);
    Task InsertMerchant(MerchantModel merchant);
}