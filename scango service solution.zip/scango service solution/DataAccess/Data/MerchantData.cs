﻿using DataAccess.DbAccess;
using DataAccess.Models;
using Npgsql;

namespace DataAccess.Data;
public class MerchantData
{
    private readonly IPostgreSqlDataAccess _database;

    public MerchantData(IPostgreSqlDataAccess database)
    {
        _database = database;
    }

    //public async Task<MerchantModel?> GestMerchant(int merchantId)
    //{
    //    var results = await _database.LoadData<MerchantModel, dynamic>(storedProcedure: "spmerchant_getmerchant", new { MerchantId = merchantId });
    //    return results.FirstOrDefault();
    //}

    public Task InsertMerchant(MerchantModel merchant) => _database.SaveData(storedProcedure: "spmerchant_addmerchant", new
    {
        merchant.MerchantName,
        merchant.MerchantAddress,
        merchant.MerchantPhNo,
        merchant.MerchantMailId,
        merchant.GSTNumber,
        merchant.FSSAINumber,
        merchant.MerchantLogoPath
    });

}
