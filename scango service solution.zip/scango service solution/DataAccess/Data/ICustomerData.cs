﻿using DataAccess.Models;

namespace DataAccess.Data;
public interface ICustomerData
{
    Task<CustomerModel?> GetCustomer(int p_customerid);
    Task<CustomerModel?> GetCustomers();
    Task InsertCustomer(CustomerModel customer);
}