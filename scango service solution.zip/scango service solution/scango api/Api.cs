﻿using DataAccess.Models;

namespace scangoapi;

public static class Api
{
    public static void ConfigureApi(this WebApplication app)
    {
        //All of API Endpoint mapping
        app.MapGet(pattern: "/Customers/{id}", GetCustomer);
        app.MapGet(pattern: "/Customers", GetCustomers);
        app.MapPost(pattern: "/customers", AddCustomer);

    }

    private static async Task<IResult> GetCustomer(int customerId, ICustomerData customerData)
    {
        try
        {
            var results =  await customerData.GetCustomer(customerId);
            if (results == null) return Results.NotFound();
            return Results.Ok(results);
        }
        catch (Exception ex)
        {

            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult> GetCustomers(ICustomerData customerData)
    {
        try
        {
            return Results.Ok(await customerData.GetCustomers());
        }
        catch (Exception ex)
        {

            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult> AddCustomer(CustomerModel customerModel, ICustomerData customerData)
    {
        try
        {
            await customerData.InsertCustomer(customerModel);
            return Results.Ok();
        }
        catch (Exception ex)
        {

            return Results.Problem(ex.Message);
        }
    }
}
