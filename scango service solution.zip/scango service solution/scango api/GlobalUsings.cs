﻿global using DataAccess.Data;
